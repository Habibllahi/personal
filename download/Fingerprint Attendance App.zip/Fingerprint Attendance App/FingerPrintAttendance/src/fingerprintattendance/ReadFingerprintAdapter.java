
package fingerprintattendance;
import com.digitalpersona.uareu.*;

public class  ReadFingerprintAdapter implements Reader{


        @Override
        public void Open(Priority prt) throws UareUException {
         
        }

        @Override
        public void Close() throws UareUException {
           
        }

        @Override
        public Status GetStatus() throws UareUException {
           
        return null;
        }

        @Override
        public Capabilities GetCapabilities() {
        return null;
            
        }

        @Override
        public Description GetDescription() {
        return null;
            
        }

        @Override
        public CaptureResult Capture(Fid.Format format, ImageProcessing ip, int i, int i1) throws UareUException {
        return null;
            
        }

        @Override
        public void CaptureAsync(Fid.Format format, ImageProcessing ip, int i, int i1, CaptureCallback cc) throws UareUException {
         
        }

        @Override
        public void CancelCapture() throws UareUException {
          
        }

        @Override
        public void StartStreaming() throws UareUException {
            
        }

        @Override
        public void StopStreaming() throws UareUException {
            
        }

        @Override
        public CaptureResult GetStreamImage(Fid.Format format, ImageProcessing ip, int i) throws UareUException {
        return null;
            
        }

        @Override
        public void Calibrate() throws UareUException {
            
        }

        @Override
        public void Reset() throws UareUException {
            
        }
    
}
