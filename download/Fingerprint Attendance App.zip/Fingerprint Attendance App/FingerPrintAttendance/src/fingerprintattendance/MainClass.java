/*
*This project is an Application that uses Finger Print module to take attendance via USB communication
*The attendee data is Registered in to MySQL data Base using the registration window
*The attendance window allows antendee to mark attendance fettching there Name, and ID data from the data base
*Also write the punctuality status to the data base and to a Label on screen
 */
package fingerprintattendance;

/**
 *This Application is develop by Hamzat Habibllahi Adewale(2018) @ HIC mikroLAB
 */
import com.digitalpersona.uareu.*;
import javax.swing.JOptionPane;
import com.mysql.jdbc.*; //importing the mySQL connector 8.0
import java.sql.*; //importing the JDBC 
public class MainClass{
    //loading the .dll libraries whose directory as been added to the java.library.path
   static{
        try{
            System.loadLibrary("dpuareu_jni");
        }catch(UnsatisfiedLinkError|SecurityException|NullPointerException e){
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error loading DLL file",JOptionPane.ERROR_MESSAGE);
        }
    }
        public static void main(String args[]) throws UareUException,SQLException {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
 //establis connection with database
new DataBaseManager();
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run(){
               
                
                new LoginWindow().setVisible(true);
                
            }
        });
//      Enrollment enroll = new Enrollment();
    }//end of main method.

       
}
