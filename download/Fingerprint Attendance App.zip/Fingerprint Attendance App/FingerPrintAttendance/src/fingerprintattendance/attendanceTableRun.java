/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fingerprintattendance;

import com.mysql.jdbc.*; //importing the mySQL connector 8.0
import java.sql.*; //importing the JDBC 
import javax.swing.JOptionPane;

public class attendanceTableRun extends DataBaseManager{
    private PreparedStatement attendanceStatement = null;
    private String name;
    private String id;
    private int year;
    private String month;
    private int day;
    private int hour;
    private int minute;
    private int seconds;
 
    private String query =  "insert into attendance(ID,NAME,YEAR,MONTH,DAY,HOUR,MINUTE,SECONDS) VALUES(?,?,?,?,?,?,?,?)";
    public attendanceTableRun() throws SQLException{

        //get parameters needed to write in to attendance table of the data base
        getParameters();
        //create statement
        try{
            attendanceStatement = connector.prepareStatement(query);
                    //setting all variables in the query 
            attendanceStatement.setString(1, id);
            attendanceStatement.setString(2, name);
            attendanceStatement.setInt(3, year);
            attendanceStatement.setString(4, month);
            attendanceStatement.setInt(5, day);
            attendanceStatement.setInt(6, hour);
            attendanceStatement.setInt(7, minute);
            attendanceStatement.setInt(8, seconds);
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e.getMessage(), "could not create statement for attendance table", JOptionPane.ERROR_MESSAGE);
        }
        try{
             int count = attendanceStatement.executeUpdate();
             System.out.println("Insertion in to attendance DB sucessful "+ "number of row affected is: " + count);
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e.getMessage(), "could not update attendance table", JOptionPane.ERROR_MESSAGE);
        }
        
        attendanceStatement.close();
        connector.close();
        

    }
    public void getParameters(){
        name = AttendanceWindow.attendeeNameCaptured;
        id = AttendanceWindow.attendeeIDCaptured;
        year = TimeManager.year;
        month = TimeManager.month.toString();
        day = TimeManager.day;
        hour = TimeManager.hour;
        minute = TimeManager.minute;
        seconds = TimeManager.seconds;  
    }
}
