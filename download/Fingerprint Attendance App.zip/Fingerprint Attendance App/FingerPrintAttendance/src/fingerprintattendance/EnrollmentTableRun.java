
package fingerprintattendance;

import com.mysql.jdbc.*; //importing the mySQL connector 8.0
import java.io.ByteArrayInputStream;
import java.sql.*; //importing the JDBC 
import javax.swing.JOptionPane;

public class EnrollmentTableRun extends DataBaseManager {
    private PreparedStatement enrollStatement = null;
        private String name;
        private String id;
        private String position;
        private String query = "insert into enrollment(ID,NAME,POSITION,RIGHT_FMD,LEFT_FMD) VALUES(?,?,?,?,?)";
        private Blob left_fmd;
        private Blob right_fmd;
   
   // private String query = "INSERT TO "
    public EnrollmentTableRun() throws SQLException{
    //get parameters to be written in to enrollment table of the database
        getParameters();
    //create statement 
       try{
       enrollStatement = connector.prepareStatement(query);
       enrollStatement.setString(1,id);
       enrollStatement.setString(2, name);
       enrollStatement.setString(3, position);
       //convert the fmd in to ByteArrayStream and set the byteArray as blob for storage in to database
       enrollStatement.setBlob(4, new ByteArrayInputStream(AttendanceWindow.Enrolee_Right_fmd.getData()), AttendanceWindow.Enrolee_Left_fmd.getData().length);
       enrollStatement.setBlob(5, new ByteArrayInputStream(AttendanceWindow.Enrolee_Left_fmd.getData()), AttendanceWindow.Enrolee_Left_fmd.getData().length);          
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null, e.getMessage(), "could not create statement for enrollment table", JOptionPane.ERROR_MESSAGE);
       }
       try{
          int count =  enrollStatement.executeUpdate();
          System.out.println("Insertion in to enrollment DB sucessful "+ "number of row affected is: " + count);
       }
       catch(SQLException e){
            JOptionPane.showMessageDialog(null, e.getMessage(), "could not update enrollment table", JOptionPane.ERROR_MESSAGE);
               }
       enrollStatement.close();
       connector.close();
    }   
    
    public void getParameters(){
        name = AttendanceWindow.enroleeNameCaptured;
        id = AttendanceWindow.enroleeIDCaptured;
        position = AttendanceWindow.enroleePositionCaptured; 
        
    }
}
