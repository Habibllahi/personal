
package fingerprintattendance;

import com.mysql.jdbc.*; //importing the mySQL connector 8.0
import java.io.ByteArrayInputStream;
import java.sql.*; //importing the JDBC 
import javax.swing.JOptionPane;

public class verificationTableRun extends DataBaseManager{
    public String id;
    private Blob left_fmd;
    private Blob right_fmd;
    private PreparedStatement verificationStatement1 = null;
    private PreparedStatement verificationStatement2 = null;
    private String query = "insert into verification(FMD,ID) VALUES(?,?)";
    public verificationTableRun() throws SQLException{
        getParameter();
    try{
        verificationStatement1 = connector.prepareStatement(query);
        //convert the fmd in to ByteArrayStream and set the byteArray as blob for storage in to database
        verificationStatement1.setBlob(1, new ByteArrayInputStream(AttendanceWindow.Enrolee_Left_fmd.getData()), AttendanceWindow.Enrolee_Left_fmd.getData().length);
        
        verificationStatement1.setString(2, id);
    }catch(SQLException|NullPointerException e){
        JOptionPane.showMessageDialog(null, e.getMessage(), "could not create first statement for verification table", JOptionPane.ERROR_MESSAGE);
    }
     try{
        verificationStatement2 = connector.prepareStatement(query);
        //convert the fmd in to ByteArrayStream and set the byteArray as blob for storage in to database
        verificationStatement2.setBlob(1, new ByteArrayInputStream(AttendanceWindow.Enrolee_Right_fmd.getData()), AttendanceWindow.Enrolee_Right_fmd.getData().length);
        
        verificationStatement2.setString(2, id);
    }catch(SQLException|NullPointerException e){
        JOptionPane.showMessageDialog(null, e.getMessage(), "could not create second statement for verification table", JOptionPane.ERROR_MESSAGE);
    }
     try{
          int count =  verificationStatement1.executeUpdate();
          System.out.println(" First Insertion in to verificatio DB sucessful "+ "number of row affected is: " + count);
       }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e.getMessage(), "could not update first statement in to  enrollment table", JOptionPane.ERROR_MESSAGE);
               }
     try{
          int count =  verificationStatement2.executeUpdate();
          System.out.println(" Second Insertion in to verificatio DB sucessful "+ "number of row affected is: " + count);
       }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e.getMessage(), "could not update second statement in to  enrollment table", JOptionPane.ERROR_MESSAGE);
               }
    verificationStatement1.close();
    verificationStatement2.close();
    connector.close();
    }

   public void getParameter(){
       id = AttendanceWindow.enroleeIDField.getText();
       System.out.println(">>>>>>>>>> ID is "+ id);
       
   }
}
