
package fingerprintattendance;
import com.digitalpersona.uareu.*;
import static fingerprintattendance.AttendanceWindow.NotificationLabel;
import static fingerprintattendance.AttendanceWindow.m_reader;
import static fingerprintattendance.AttendanceWindow.notificationLabel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
public class ReaderWindow extends javax.swing.JFrame {

    /**
     * Creates new form ReaderWindow
     */
    public ReaderWindow() {
        initComponents();
        setVisible(true);
        btnBack.setToolTipText("Close");
        btnRefresh.setToolTipText("Reload Reader List");
        btnGetCaps.setToolTipText("Get the Scnanner capability");
        selection = new Selection(AttendanceWindow.m_collection);
    }
//creating selection class as na inner class to Reader window<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Selection inner class<<<<<<<<<<<<<<<<<<<<<<<<<
public static class Selection implements ActionListener
{
    	private static final long serialVersionUID = 2;
	private static final String ACT_BACK = "back";
	private static final String ACT_REFRESH = "refresh";
	private static final String ACT_GETCAPS = "getCapability";
        private ReaderCollection m_collection; 
        
	private Selection(ReaderCollection collection){
		m_collection = collection;
		m_listReaders.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		btnRefresh.setActionCommand(ACT_REFRESH);
		btnRefresh.addActionListener(this);
		btnGetCaps.setActionCommand(ACT_GETCAPS);
                btnGetCaps.addActionListener(this);
		m_listReaders.setOpaque(true);
	}
        
	private void RefreshList(){
		//acquire available readers
		try{
			m_collection.GetReaders();
		} 
		catch(UareUException e) { 
			JOptionPane.showMessageDialog(null, e.getMessage(), "Refresh Error", JOptionPane.ERROR_MESSAGE);
		}
		//list reader names
		Vector<String> strNames = new Vector<String>();
		for(int i = 0; i < m_collection.size(); i++){
			strNames.add(m_collection.get(i).GetDescription().name);
		}
		m_listReaders.setListData(strNames);
	}
        
       private Reader getSelectedReader(){
		if(-1 == m_listReaders.getSelectedIndex()) return null;
		return m_collection.get(m_listReaders.getSelectedIndex());
	}
	private void doModal(){
		RefreshList();
	}
       
        @Override
	public void actionPerformed(ActionEvent e){
		if(e.getActionCommand().equals(ACT_REFRESH)){
			RefreshList();
		}
		if(e.getActionCommand().equals(ACT_GETCAPS)){
			Reader reader = getSelectedReader();
		if(null != reader) Capabilities.Show(reader);
		}
	}
        public static void  Select(){
            ReaderWindow readerWindoww = new ReaderWindow();
            selection.doModal();
		
	}
    
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        availableReaderLabel = new javax.swing.JLabel();
        buttonPanel = new javax.swing.JPanel();
        btnBack = new javax.swing.JButton();
        btnRefresh = new javax.swing.JButton();
        btnGetCaps = new javax.swing.JButton();
        readerPane = new javax.swing.JScrollPane();
        m_listReaders = new javax.swing.JList();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        availableReaderLabel.setText("Available Readers are:");
        availableReaderLabel.setMaximumSize(new java.awt.Dimension(300, 16));
        availableReaderLabel.setMinimumSize(new java.awt.Dimension(300, 16));
        availableReaderLabel.setPreferredSize(new java.awt.Dimension(300, 16));
        getContentPane().add(availableReaderLabel, java.awt.BorderLayout.PAGE_START);

        buttonPanel.setMaximumSize(new java.awt.Dimension(300, 40));
        buttonPanel.setMinimumSize(new java.awt.Dimension(300, 40));
        buttonPanel.setPreferredSize(new java.awt.Dimension(300, 40));

        btnBack.setLabel("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        buttonPanel.add(btnBack);

        btnRefresh.setText("Refresh");
        buttonPanel.add(btnRefresh);

        btnGetCaps.setText("Capability");
        buttonPanel.add(btnGetCaps);

        getContentPane().add(buttonPanel, java.awt.BorderLayout.PAGE_END);

        m_listReaders.setToolTipText("");
        m_listReaders.setMaximumSize(new java.awt.Dimension(300, 200));
        m_listReaders.setMinimumSize(new java.awt.Dimension(300, 200));
        m_listReaders.setPreferredSize(new java.awt.Dimension(300, 200));
        readerPane.setViewportView(m_listReaders);

        getContentPane().add(readerPane, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
       AttendanceWindow.m_reader = selection.getSelectedReader();
                       if(null != m_reader){
				notificationLabel.setText(m_reader.GetDescription().name);
                                NotificationLabel.setText(m_reader.GetDescription().name);
			}
			else{
				notificationLabel.setText("No Reader Selected");
                                NotificationLabel.setText("No Reader Selected");
			}
        this.setVisible(false);
    }//GEN-LAST:event_btnBackActionPerformed

    public static Selection selection;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel availableReaderLabel;
    public static javax.swing.JButton btnBack;
    public static javax.swing.JButton btnGetCaps;
    public static javax.swing.JButton btnRefresh;
    private javax.swing.JPanel buttonPanel;
    private javax.swing.JLabel jLabel1;
    public static javax.swing.JList m_listReaders;
    private javax.swing.JScrollPane readerPane;
    // End of variables declaration//GEN-END:variables
}
