
package fingerprintattendance;

import com.digitalpersona.uareu.*;
import com.digitalpersona.uareu.Fid.Fiv;
import com.mysql.jdbc.*;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.sql.SQLException;
import javax.swing.JOptionPane;

import javax.swing.JPanel;


public class AttendanceWindow extends JFrame{


    public AttendanceWindow(){
        initComponents();
        EnrollButton.setActionCommand(ACT_ENROLLMENT);
        verifyButton.setActionCommand(ACT_VERIFICATION);
        openReaderButton.setActionCommand(ACT_SELECTION);
        PortGateButton.setActionCommand(ACT_SELECTION);
        attendanceCatptureButton.setActionCommand(ATTENDANCE_CAPTURE_COMMAND);
         enroleeCaptureButton.setActionCommand(ENROLEE_CAPTURE_COMMAND);
         m_image = new ImagePanel();
         left_m_image = new ImagePanel();
         right_m_image = new ImagePanel();
         Dimension dm = new Dimension(200, 200);
          m_image.setPreferredSize(dm);
          left_m_image.setPreferredSize(dm);
          right_m_image.setPreferredSize(dm);
         imagePanel.add(m_image);
         left_imagePanel.add(left_m_image);
         right_imagePanel.add(right_m_image);
        setVisible(true);
        AttendanceTabPane.setToolTipTextAt(0, "Verification Window");
        AttendanceTabPane.setToolTipTextAt(1, "Enrollment Window");
        AttendanceTabPane.setTabLayoutPolicy(JTabbedPane.WRAP_TAB_LAYOUT);
        AttendanceTabPane.setTitleAt(0, "Verification");
        AttendanceTabPane.setTitleAt(1, "Enrollment");
        AttendanceTabPane.setTabPlacement(JTabbedPane.TOP);//set the Tab Placement
        //set tooltips for buttons
        openReaderButton.setToolTipText("Open Connection with the scanner");
        attendanceCatptureButton.setToolTipText("Click to capture finger");
        queryAttendanceTable.setToolTipText("Find out who attended");
        verifyButton.setToolTipText("Click to mark attendance");
        ReleaseAttendanceResources.setToolTipText("Click to Stop Reader Connection");
        PortGateButton.setToolTipText("Open Connection with the scanner");
        enroleeCaptureButton.setToolTipText("Click to capture finger");
        queryEnrollmentTable.setToolTipText("Find out who attended");
        EnrollButton.setToolTipText("Click to enroll");
        ReleaseEnrollResouces.setToolTipText("Click to Stop Reader Connection");
           try{
                   m_collection = UareUGlobal.GetReaderCollection();
		}
		catch(UareUException e) {
                    DpError("UareUGlobal.getReaderCollection()", e);
                    return;
		}
    }
//creating Image Panel as an inner class to attendance window<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<ImagePanel inner class<<<<<<<<<<<<<<<<<<<<<<<<
public class ImagePanel extends JPanel
{
	private static final long serialVersionUID = 5;
	private BufferedImage BufferedImage_view;


//the method showImage() takes an FID and get its FIV then process the FIV to display as an array of mapped pixel showing the fingerprint	
	public void showImage(Fid image){
          //this condition is put inplace to uniquely identify FID of Attendance capture and store the generated FIV in Attendance_view
            if(AttendanceFlag == true){
		Attendance_view = image.getViews()[0]; //store the generated FIV for this FID into an FIV variable called Attendance_view 
		BufferedImage_view = new BufferedImage(Attendance_view.getWidth(), Attendance_view.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
		BufferedImage_view.getRaster().setDataElements(0, 0, Attendance_view.getWidth(), Attendance_view.getHeight(), Attendance_view.getImageData());
		repaint();
            }
         //this condition is put inplace to uniquely identify FID of Left Finger capture and store the generated FIV in Enrolee_Left_view
            if(Enroll_Left_Flag == true && Enroll_Right_Flag == false){
                Enrolee_Left_view = image.getViews()[0]; //store the generated FIV for this FID into an FIV variable called Enrolee_Left_view
		BufferedImage_view = new BufferedImage(Enrolee_Left_view.getWidth(), Enrolee_Left_view.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
		BufferedImage_view.getRaster().setDataElements(0, 0, Enrolee_Left_view.getWidth(), Enrolee_Left_view.getHeight(), Enrolee_Left_view.getImageData());
		repaint(); 
            }
         //this condition is put inplace to uniquely identify FID of Right Finger capture and store the generated FIV in Enrolee_Right_view
            if(Enroll_Right_Flag == true){
                Enrolee_Right_view = image.getViews()[0]; //store the generated FIV for this FID into an FIV variable called Enrolee_Right_view
		BufferedImage_view = new BufferedImage(Enrolee_Right_view.getWidth(), Enrolee_Right_view.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
		BufferedImage_view.getRaster().setDataElements(0, 0, Enrolee_Right_view.getWidth(), Enrolee_Right_view.getHeight(), Enrolee_Right_view.getImageData());
		repaint(); 
            }
	} 
	
	public void paint(Graphics g) {
		g.drawImage(BufferedImage_view, 0, 0, null);
	}

}//end of image panel inner class


//creating a capture class as an inner class to attendance window<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Capture inner class<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
public static class Capture implements ActionListener{
    	public static final long serialVersionUID = 2;
	public static final String ACT_BACK = "StopCapture";
	private CaptureThread m_capture;
	private Reader        m_reader;
        private Fmd[]   m_fmds;
	//public ImagePanel     m_image;
	private boolean       m_bStreaming;
        private Capture(Reader reader, boolean bStreaming){
                m_reader = reader;
		m_bStreaming = bStreaming;
		
		m_capture = new CaptureThread(m_reader, m_bStreaming, AppConstants.captureFormat, AppConstants.ImageProcessingType);
                queryEnrollmentTable.setActionCommand(ACT_BACK);
                queryAttendanceTable.setActionCommand(ACT_BACK);
		queryEnrollmentTable.addActionListener(this);
                queryAttendanceTable.addActionListener(this);
        
        }
        //method to initiate capturing thread; a thread that brings about FID
        private void StartCaptureThread(){
		m_capture = new CaptureThread(m_reader, m_bStreaming, AppConstants.captureFormat, AppConstants.ImageProcessingType);
		m_capture.start(this);
	}
        //method to Stop capturing thread; a thread that brings about FID
        private void StopCaptureThread(){
		if(null != m_capture) m_capture.cancel();
	}
        //a methos to wait for capturing to complete and set to 3 secs
        private void WaitForCaptureThread(){
		if(null != m_capture) m_capture.join(3000);
	}
        
        //prety defined here exclusively the evnts associated to capturing 
         @Override
        public void actionPerformed(ActionEvent e) {
           if(e.getActionCommand().equals(ACT_BACK)){
			//event from "End" button
			//cancel capture
			StopCaptureThread();
                        notificationLabel.setText("Capture thread stoped");
                        NotificationLabel.setText("Capture thread stoped");
                  //Open Query window
                        //new AttendanceQueryWindow();  
                        new AttendanceQueryWindowUpdate();
                    
           }else if(e.getActionCommand().equals(CaptureThread.ACT_CAPTURE)){
			//event from capture thread
			 evt = (CaptureThread.CaptureEvent)e;
			boolean bCanceled = false;
			
			if(null != evt.capture_result){
                          //evt.capture_result.image is use to call the imidiate FID under current capturing 
				if(null != evt.capture_result.image && Reader.CaptureQuality.GOOD == evt.capture_result.quality){
					//display image
                                    if(AppConstants.captureForWhat.equals(ATTENDANCE_CAPTURE_COMMAND)){
                                      m_image.showImage(evt.capture_result.image); 
                                      notificationLabel.setText("Good Quality");
                                      AttendanceFlag = false;
                                      ProcessAttendanceCaptureResult(evt);
                                      TimeManager.getLocalDate_Time();
                                      StopCaptureThread();
                                    }
              
                                    if(AppConstants.captureForWhat.equals(ENROLEE_CAPTURE_COMMAND)){
                                        if(Enroll_Left_Flag == true && Enroll_Right_Flag == false ){
                                            left_m_image.showImage(evt.capture_result.image); 
                                            NotificationLabel.setText("Good Quality @ 1st Capture");
                                            JOptionPane.showMessageDialog(null, "Enroll with an alternative finger", "Sucessful", JOptionPane.INFORMATION_MESSAGE);
                                            ProcessEnrolee_LeftCaptureResult(evt);
                                            //TimeManager.getLocalDate_Time();
                                        }
                                        if(Enroll_Right_Flag == true){
                                            right_m_image.showImage(evt.capture_result.image); 
                                            NotificationLabel.setText("Good Quality @ 2nd Capture");
                                            ProcessEnrolee_RightCaptureResult(evt);
                                            //TimeManager.getLocalDate_Time();
                                        }
                                       Enroll_Left_Flag = false;
                                            if(Enroll_Right_Flag == false){
                                                Enroll_Right_Flag = true; 
                                            }else{
                                                Enroll_Right_Flag = false; 
                                            }
                                       StopCaptureThread();
                                   
                                    }
                                }
				else if(Reader.CaptureQuality.CANCELED == evt.capture_result.quality){
					//capture or streaming was canceled, just quit
					bCanceled = true;
                                        NotificationLabel.setText("canceled");
                                        notificationLabel.setText("canceled");
				}
				else{
					//bad quality
                                        BadQuality(evt.capture_result.quality);
                                       notificationLabel.setText("Bad Quality");
                                       NotificationLabel.setText("Bad Quality");
                                    
			}
                        }
			else if(null != evt.exception){
				//exception during capture
				DpError("Capture",  evt.exception);      
				bCanceled = true;
			}
			else if(null != evt.reader_status){
                            BadStatus(evt.reader_status);
			    bCanceled = true;
			}
			
			if(!bCanceled){
				if(!m_bStreaming){
					//restart capture thread
					WaitForCaptureThread();
					StartCaptureThread();
				}
			}
			else{
				//destroy dialog
				
			}
		}
        
        
       }
        
	private void doModal(){
		//open reader
		try{
			m_reader.Open(Reader.Priority.COOPERATIVE);
		}
		catch(UareUException e){
                    JOptionPane.showMessageDialog(null, e.toString(), "Error Opening Reader", JOptionPane.ERROR_MESSAGE); 
                }
		
		boolean bOk = true;
		if(m_bStreaming){
			//check if streaming supported
			Reader.Capabilities rc = m_reader.GetCapabilities();
			if(!rc.can_stream){
				JOptionPane.showMessageDialog(null, "This Reader Those not support streaming" , "Streaming Error", JOptionPane.ERROR_MESSAGE);
				bOk = false;
			}
		}
		
		if(bOk){
			//start capture thread
			StartCaptureThread();
			
			//wait for capture thread to finish
			WaitForCaptureThread();
		}
		
		//close reader
		try{
			m_reader.Close();
		}
		catch(UareUException e){
                    JOptionPane.showMessageDialog(null, e.toString() , "Error Closing Reader", JOptionPane.ERROR_MESSAGE); 
                }
	}

    	public static void Run(Reader reader, boolean bStreaming){
    	notificationLabel.setText("place your finger on the reader");
        NotificationLabel.setText("place your finger on the reader");
    	Capture capture = new Capture(reader, bStreaming);
    	capture.doModal();
	}
}//end of capture class

//creating Enrollment  class as an inner class in Attendance Window<<<<<<<<<<<<<<<<<<<<<<<<<<<<<Enrollment class as an  Inner class<<<<<<<<<<<<<<<<<<<<<<

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        AttendanceTabPane = new javax.swing.JTabbedPane();
        verificationPanel = new javax.swing.JPanel();
        attendeeDetailPane = new javax.swing.JPanel();
        attendeeNameLabel = new javax.swing.JLabel();
        attendeeNameField = new javax.swing.JTextField();
        attendeeIDLabel = new javax.swing.JLabel();
        attendeeIDField = new javax.swing.JTextField();
        attendeeButtonPane = new javax.swing.JPanel();
        openReaderButton = new javax.swing.JButton();
        attendanceCatptureButton = new javax.swing.JButton();
        queryAttendanceTable = new javax.swing.JButton();
        verifyButton = new javax.swing.JButton();
        ReleaseAttendanceResources = new javax.swing.JButton();
        notificationLabel = new javax.swing.JLabel();
        statusLabel = new javax.swing.JLabel();
        imagePanel = new javax.swing.JPanel();
        enrollmentPanel = new javax.swing.JPanel();
        EnroleeDetailsPane = new javax.swing.JPanel();
        enroleeName = new javax.swing.JLabel();
        enroleeNameField = new javax.swing.JTextField();
        enroleeID = new javax.swing.JLabel();
        enroleeIDField = new javax.swing.JTextField();
        enroleePosition = new javax.swing.JLabel();
        enroleePositionField = new javax.swing.JTextField();
        enrollButtonPanel = new javax.swing.JPanel();
        PortGateButton = new javax.swing.JButton();
        enroleeCaptureButton = new javax.swing.JButton();
        queryEnrollmentTable = new javax.swing.JButton();
        EnrollButton = new javax.swing.JButton();
        ReleaseEnrollResouces = new javax.swing.JButton();
        NotificationLabel = new javax.swing.JLabel();
        left_imagePanel = new javax.swing.JPanel();
        right_imagePanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(500, 500));

        AttendanceTabPane.setMaximumSize(new java.awt.Dimension(480, 480));
        AttendanceTabPane.setMinimumSize(new java.awt.Dimension(480, 480));
        AttendanceTabPane.setPreferredSize(new java.awt.Dimension(480, 480));

        verificationPanel.setMaximumSize(new java.awt.Dimension(495, 470));
        verificationPanel.setMinimumSize(new java.awt.Dimension(495, 470));
        verificationPanel.setLayout(new java.awt.BorderLayout());

        attendeeDetailPane.setMaximumSize(new java.awt.Dimension(480, 100));
        attendeeDetailPane.setMinimumSize(new java.awt.Dimension(480, 100));
        attendeeDetailPane.setPreferredSize(new java.awt.Dimension(480, 100));
        attendeeDetailPane.setLayout(new java.awt.GridLayout(2, 2, 2, 2));

        attendeeNameLabel.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        attendeeNameLabel.setText("NAME");
        attendeeNameLabel.setMaximumSize(new java.awt.Dimension(40, 16));
        attendeeNameLabel.setMinimumSize(new java.awt.Dimension(40, 16));
        attendeeNameLabel.setPreferredSize(new java.awt.Dimension(40, 16));
        attendeeDetailPane.add(attendeeNameLabel);

        attendeeNameField.setMaximumSize(new java.awt.Dimension(180, 16));
        attendeeNameField.setMinimumSize(new java.awt.Dimension(180, 16));
        attendeeNameField.setPreferredSize(new java.awt.Dimension(180, 16));
        attendeeDetailPane.add(attendeeNameField);

        attendeeIDLabel.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        attendeeIDLabel.setText("ID");
        attendeeIDLabel.setMaximumSize(new java.awt.Dimension(40, 16));
        attendeeIDLabel.setMinimumSize(new java.awt.Dimension(40, 16));
        attendeeIDLabel.setPreferredSize(new java.awt.Dimension(40, 16));
        attendeeDetailPane.add(attendeeIDLabel);

        attendeeIDField.setMaximumSize(new java.awt.Dimension(180, 16));
        attendeeIDField.setMinimumSize(new java.awt.Dimension(180, 16));
        attendeeIDField.setPreferredSize(new java.awt.Dimension(180, 16));
        attendeeIDField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attendeeIDFieldActionPerformed(evt);
            }
        });
        attendeeDetailPane.add(attendeeIDField);

        verificationPanel.add(attendeeDetailPane, java.awt.BorderLayout.PAGE_START);

        attendeeButtonPane.setMaximumSize(new java.awt.Dimension(480, 70));
        attendeeButtonPane.setMinimumSize(new java.awt.Dimension(480, 70));
        attendeeButtonPane.setPreferredSize(new java.awt.Dimension(480, 70));

        openReaderButton.setText("Open Reader");
        openReaderButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openReaderButtonActionPerformed(evt);
            }
        });
        attendeeButtonPane.add(openReaderButton);

        attendanceCatptureButton.setText("Capture");
        attendanceCatptureButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                attendanceCatptureButtonActionPerformed(evt);
            }
        });
        attendeeButtonPane.add(attendanceCatptureButton);

        queryAttendanceTable.setText("Query DB");
        queryAttendanceTable.setActionCommand("ATTENDANCETABLE");
        queryAttendanceTable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                queryAttendanceTableActionPerformed(evt);
            }
        });
        attendeeButtonPane.add(queryAttendanceTable);

        verifyButton.setText("Attendance");
        verifyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verifyButtonActionPerformed(evt);
            }
        });
        attendeeButtonPane.add(verifyButton);

        ReleaseAttendanceResources.setText("End");
        ReleaseAttendanceResources.setActionCommand("ReleaseResources");
        ReleaseAttendanceResources.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReleaseAttendanceResourcesActionPerformed(evt);
            }
        });
        attendeeButtonPane.add(ReleaseAttendanceResources);

        notificationLabel.setMaximumSize(new java.awt.Dimension(180, 25));
        notificationLabel.setMinimumSize(new java.awt.Dimension(180, 25));
        notificationLabel.setPreferredSize(new java.awt.Dimension(180, 25));
        attendeeButtonPane.add(notificationLabel);

        verificationPanel.add(attendeeButtonPane, java.awt.BorderLayout.PAGE_END);

        statusLabel.setMaximumSize(new java.awt.Dimension(270, 200));
        statusLabel.setMinimumSize(new java.awt.Dimension(270, 200));
        statusLabel.setPreferredSize(new java.awt.Dimension(270, 200));
        verificationPanel.add(statusLabel, java.awt.BorderLayout.CENTER);

        imagePanel.setMaximumSize(new java.awt.Dimension(200, 200));
        imagePanel.setMinimumSize(new java.awt.Dimension(200, 200));
        imagePanel.setPreferredSize(new java.awt.Dimension(200, 200));
        verificationPanel.add(imagePanel, java.awt.BorderLayout.LINE_START);

        AttendanceTabPane.addTab("tab2", verificationPanel);

        enrollmentPanel.setMaximumSize(new java.awt.Dimension(495, 470));
        enrollmentPanel.setMinimumSize(new java.awt.Dimension(495, 470));
        enrollmentPanel.setLayout(new java.awt.BorderLayout());

        EnroleeDetailsPane.setMaximumSize(new java.awt.Dimension(480, 150));
        EnroleeDetailsPane.setMinimumSize(new java.awt.Dimension(480, 150));
        EnroleeDetailsPane.setPreferredSize(new java.awt.Dimension(480, 150));
        EnroleeDetailsPane.setLayout(new java.awt.GridLayout(3, 2, 2, 2));

        enroleeName.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        enroleeName.setText("NAME");
        enroleeName.setMaximumSize(new java.awt.Dimension(40, 16));
        enroleeName.setMinimumSize(new java.awt.Dimension(40, 16));
        enroleeName.setPreferredSize(new java.awt.Dimension(40, 16));
        EnroleeDetailsPane.add(enroleeName);

        enroleeNameField.setMaximumSize(new java.awt.Dimension(180, 16));
        enroleeNameField.setMinimumSize(new java.awt.Dimension(180, 16));
        enroleeNameField.setName(""); // NOI18N
        enroleeNameField.setPreferredSize(new java.awt.Dimension(180, 16));
        enroleeNameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enroleeNameFieldActionPerformed(evt);
            }
        });
        EnroleeDetailsPane.add(enroleeNameField);

        enroleeID.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        enroleeID.setText("ID");
        enroleeID.setMaximumSize(new java.awt.Dimension(40, 16));
        enroleeID.setMinimumSize(new java.awt.Dimension(40, 16));
        enroleeID.setPreferredSize(new java.awt.Dimension(40, 16));
        EnroleeDetailsPane.add(enroleeID);

        enroleeIDField.setMaximumSize(new java.awt.Dimension(180, 16));
        enroleeIDField.setMinimumSize(new java.awt.Dimension(180, 16));
        enroleeIDField.setPreferredSize(new java.awt.Dimension(180, 16));
        EnroleeDetailsPane.add(enroleeIDField);

        enroleePosition.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        enroleePosition.setText("POSITION");
        enroleePosition.setMaximumSize(new java.awt.Dimension(40, 16));
        enroleePosition.setMinimumSize(new java.awt.Dimension(40, 16));
        enroleePosition.setPreferredSize(new java.awt.Dimension(40, 16));
        EnroleeDetailsPane.add(enroleePosition);

        enroleePositionField.setMaximumSize(new java.awt.Dimension(180, 16));
        enroleePositionField.setMinimumSize(new java.awt.Dimension(180, 16));
        enroleePositionField.setPreferredSize(new java.awt.Dimension(180, 16));
        enroleePositionField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enroleePositionFieldActionPerformed(evt);
            }
        });
        EnroleeDetailsPane.add(enroleePositionField);

        enrollmentPanel.add(EnroleeDetailsPane, java.awt.BorderLayout.PAGE_START);

        enrollButtonPanel.setMaximumSize(new java.awt.Dimension(480, 70));
        enrollButtonPanel.setMinimumSize(new java.awt.Dimension(480, 70));
        enrollButtonPanel.setPreferredSize(new java.awt.Dimension(480, 70));
        enrollButtonPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        PortGateButton.setText("Open Reader");
        PortGateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PortGateButtonActionPerformed(evt);
            }
        });
        enrollButtonPanel.add(PortGateButton);

        enroleeCaptureButton.setText("Capture");
        enroleeCaptureButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enroleeCaptureButtonActionPerformed(evt);
            }
        });
        enrollButtonPanel.add(enroleeCaptureButton);

        queryEnrollmentTable.setText("Query DB");
        queryEnrollmentTable.setActionCommand("ENROLLMENTTABLE");
        queryEnrollmentTable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                queryEnrollmentTableActionPerformed(evt);
            }
        });
        enrollButtonPanel.add(queryEnrollmentTable);

        EnrollButton.setText("Enroll");
        EnrollButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EnrollButtonActionPerformed(evt);
            }
        });
        enrollButtonPanel.add(EnrollButton);

        ReleaseEnrollResouces.setText("End");
        ReleaseEnrollResouces.setActionCommand("ReleaseResources");
        ReleaseEnrollResouces.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReleaseEnrollResoucesActionPerformed(evt);
            }
        });
        enrollButtonPanel.add(ReleaseEnrollResouces);

        NotificationLabel.setMaximumSize(new java.awt.Dimension(180, 25));
        NotificationLabel.setMinimumSize(new java.awt.Dimension(180, 25));
        NotificationLabel.setPreferredSize(new java.awt.Dimension(180, 25));
        enrollButtonPanel.add(NotificationLabel);

        enrollmentPanel.add(enrollButtonPanel, java.awt.BorderLayout.PAGE_END);

        left_imagePanel.setMaximumSize(new java.awt.Dimension(200, 200));
        left_imagePanel.setMinimumSize(new java.awt.Dimension(200, 200));
        left_imagePanel.setPreferredSize(new java.awt.Dimension(200, 200));
        enrollmentPanel.add(left_imagePanel, java.awt.BorderLayout.LINE_START);

        right_imagePanel.setMaximumSize(new java.awt.Dimension(200, 200));
        right_imagePanel.setMinimumSize(new java.awt.Dimension(200, 200));
        right_imagePanel.setPreferredSize(new java.awt.Dimension(200, 200));
        enrollmentPanel.add(right_imagePanel, java.awt.BorderLayout.LINE_END);

        AttendanceTabPane.addTab("tab1", enrollmentPanel);

        getContentPane().add(AttendanceTabPane, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void enroleeNameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enroleeNameFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_enroleeNameFieldActionPerformed

    private void enroleePositionFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enroleePositionFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_enroleePositionFieldActionPerformed

    private void EnrollButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EnrollButtonActionPerformed
        // Capture the data filed in to the fields
        enroleeNameCaptured = enroleeNameField.getText();
        enroleeIDCaptured = enroleeIDField.getText();
        enroleePositionCaptured = enroleePositionField.getText();
        
        //try to enroll this candidiate 
        try{
            new EnrollmentTableRun();
        }catch(SQLException e){
           JOptionPane.showMessageDialog(null, e.getMessage(), "could not create object of EnrollmentTableRun class ", JOptionPane.ERROR_MESSAGE);  
        }
        //try to put the enrolee on verification table so as to be able to verify his/her claimm when an attemp is made to mark attendence
        try{
            new verificationTableRun();
        }catch(SQLException e){
           JOptionPane.showMessageDialog(null, e.getMessage(), "could not create object of verificationTableRun class ", JOptionPane.ERROR_MESSAGE);  
        }
                
    }//GEN-LAST:event_EnrollButtonActionPerformed

    private void enroleeCaptureButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enroleeCaptureButtonActionPerformed

              if(evt.getActionCommand().equals(ENROLEE_CAPTURE_COMMAND)){
                 AppConstants.captureForWhat = ENROLEE_CAPTURE_COMMAND;
                 Enroll_Left_Flag = true;
                       if(null == m_reader){
				Warning("Reader is not selected");
			}
			else{
				Capture.Run(m_reader, false);
			}
		}  
         
    }//GEN-LAST:event_enroleeCaptureButtonActionPerformed

    private void PortGateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PortGateButtonActionPerformed
            //ReaderWindow readerWindoww = new ReaderWindow();
        if(evt.getActionCommand().equals(ACT_SELECTION)){
                ReaderWindow.Selection.Select();   //execute the Selection inner class of the ReaderWindow
                if(null != m_reader){
				notificationLabel.setText(m_reader.GetDescription().name);
                                NotificationLabel.setText(m_reader.GetDescription().name);
			}
			else{
				notificationLabel.setText("No Reader Selected");
                                NotificationLabel.setText("No Reader Selected");
			} 
        }   
    
    }//GEN-LAST:event_PortGateButtonActionPerformed

    private void attendeeIDFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attendeeIDFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_attendeeIDFieldActionPerformed

    private void openReaderButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openReaderButtonActionPerformed

            //ReaderWindow readerWindoww = new ReaderWindow();
        if(evt.getActionCommand().equals(ACT_SELECTION)){
                ReaderWindow.Selection.Select();   //execute the Selection inner class of the ReaderWindow
                if(null != m_reader){
				notificationLabel.setText(m_reader.GetDescription().name);
                                NotificationLabel.setText(m_reader.GetDescription().name);
			}
			else{
				notificationLabel.setText("No Reader Selected");
                                NotificationLabel.setText("No Reader Selected");
			} 
        }   
    }//GEN-LAST:event_openReaderButtonActionPerformed

    private void attendanceCatptureButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_attendanceCatptureButtonActionPerformed
             if(evt.getActionCommand().equals(ATTENDANCE_CAPTURE_COMMAND)){
                 AppConstants.captureForWhat = ATTENDANCE_CAPTURE_COMMAND;
                 AttendanceFlag = true;
                       if(null == m_reader){
				Warning("Reader is not selected");
			}
			else{
				Capture.Run(m_reader, false);
			}
		}  
    }//GEN-LAST:event_attendanceCatptureButtonActionPerformed

    private void verifyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verifyButtonActionPerformed
//fetch datas from the test fields
      attendeeNameCaptured = attendeeNameField.getText();
      attendeeIDCaptured = attendeeIDField.getText();
      
//display captured time to the user
        TimeManager.showAttendanceDetail();
//try to update the attendance table in the database if verification is a sucess
        try{
            new VerificationManager();
        }catch(SQLException e){
           JOptionPane.showMessageDialog(null, e.getMessage(), "verification not sucessful ", JOptionPane.ERROR_MESSAGE); 
        }
        try{
           new attendanceTableRun();
        }catch(SQLException e){
           JOptionPane.showMessageDialog(null, e.getMessage(), " attendanceTableRun not sucessful ", JOptionPane.ERROR_MESSAGE); 
        }
        
       
    }//GEN-LAST:event_verifyButtonActionPerformed

    private void ReleaseEnrollResoucesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReleaseEnrollResoucesActionPerformed
        if(evt.getActionCommand().equals("ReleaseResources")){
                    //release capture library by destroying reader collection
        try{
            UareUGlobal.DestroyReaderCollection();
        }
        catch(UareUException e) {
            DpError("UareUGlobal.destroyReaderCollection()", e);
        }
        }
    }//GEN-LAST:event_ReleaseEnrollResoucesActionPerformed

    private void ReleaseAttendanceResourcesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReleaseAttendanceResourcesActionPerformed
                if(evt.getActionCommand().equals("ReleaseResources")){
                    //release capture library by destroying reader collection
        try{
            UareUGlobal.DestroyReaderCollection();
        }
        catch(UareUException e) {
            DpError("UareUGlobal.destroyReaderCollection()", e);
        }
        }
    }//GEN-LAST:event_ReleaseAttendanceResourcesActionPerformed

    private void queryAttendanceTableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_queryAttendanceTableActionPerformed
        if(evt.getActionCommand().equals("ATTENDANCETABLE")){
          //new AttendanceQueryWindow();  
            new AttendanceQueryWindowUpdate();
        }
              
        
    }//GEN-LAST:event_queryAttendanceTableActionPerformed

    private void queryEnrollmentTableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_queryEnrollmentTableActionPerformed
         if(evt.getActionCommand().equals("ENROLLMENTTABLE")){
          //new AttendanceQueryWindow();  
             new AttendanceQueryWindowUpdate();
        }
    }//GEN-LAST:event_queryEnrollmentTableActionPerformed
   
//Methods adressing all kind of error messages associated with this Window   
	public static void BadQuality(Reader.CaptureQuality q){
		JOptionPane.showMessageDialog(null, q.toString(), "Bad quality", JOptionPane.WARNING_MESSAGE);
	}
	
	public static void BadStatus(Reader.Status s){
		String str = String.format("Reader status: %s", s.toString());
		JOptionPane.showMessageDialog(null, str, "Reader status", JOptionPane.ERROR_MESSAGE);
	}
	
	public static void DpError(String strFunctionName, UareUException e){
		String str = String.format("%s returned DP error %d \n%s", strFunctionName, (e.getCode() & 0xffff), e.toString());
		JOptionPane.showMessageDialog(null, str, "Error", JOptionPane.ERROR_MESSAGE);
	}

	public static void Warning(String strText){
		JOptionPane.showMessageDialog(null, strText, "Warning", JOptionPane.WARNING_MESSAGE);
	}
        
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> extraction of FMD from FID <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        // NB this process method does not include Verification codes or Enrollment codes
//Extraction for Attendace capture        
       	public static void ProcessAttendanceCaptureResult(CaptureThread.CaptureEvent evt){
		boolean bCanceled = false;

		if(null != evt.capture_result){
			if(null != evt.capture_result.image && Reader.CaptureQuality.GOOD == evt.capture_result.quality){
				//extract features
				Engine AttendanceEngine = UareUGlobal.GetEngine();
					
				try{
					Attendance_fmd = AttendanceEngine.CreateFmd(evt.capture_result.image, Fmd.Format.ANSI_378_2004);
                                        System.out.println("Attendance Finger Extraction Sucessful>>" + Attendance_fmd.toString());
				}
				catch(UareUException e){
                                    DpError("Engine.CreateFmd()", e);
                                }

		}
                  else if(Reader.CaptureQuality.CANCELED == evt.capture_result.quality){
				//capture or streaming was canceled, just quit
				bCanceled = true;
			}
			else{
				//bad quality
                            BadQuality(evt.capture_result.quality);
			}
                }
		else if(null != evt.exception){
			//exception during capture
			DpError("Capture", evt.exception);
			bCanceled = true;
		}
		else if(null != evt.reader_status){
			//reader failure
			BadStatus(evt.reader_status);
			bCanceled = true;
		}
        }
//Extraction process for Enrolee Left Finger       
       	public static void ProcessEnrolee_LeftCaptureResult(CaptureThread.CaptureEvent evt){
		boolean bCanceled = false;

		if(null != evt.capture_result){
			if(null != evt.capture_result.image && Reader.CaptureQuality.GOOD == evt.capture_result.quality){
				//extract features
				Engine LeftFingerEngine = UareUGlobal.GetEngine();
					
				try{
					Enrolee_Left_fmd = LeftFingerEngine.CreateFmd(evt.capture_result.image, Fmd.Format.ANSI_378_2004);
                                        System.out.println("Enrolee_Left Finger Extraction Sucessful>>" + Enrolee_Left_fmd.toString());
				
				}
				catch(UareUException e){
                                    DpError("Engine.CreateFmd()", e);
                                }

		}
                  else if(Reader.CaptureQuality.CANCELED == evt.capture_result.quality){
				//capture or streaming was canceled, just quit
				bCanceled = true;
			}
			else{
				//bad quality
                            BadQuality(evt.capture_result.quality);
			}
                }
		else if(null != evt.exception){
			//exception during capture
			DpError("Capture", evt.exception);
			bCanceled = true;
		}
		else if(null != evt.reader_status){
			//reader failure
			BadStatus(evt.reader_status);
			bCanceled = true;
		}
        }
//Extraction process for Enrolee Right Finger        
       	public static void ProcessEnrolee_RightCaptureResult(CaptureThread.CaptureEvent evt){
		boolean bCanceled = false;

		if(null != evt.capture_result){
			if(null != evt.capture_result.image && Reader.CaptureQuality.GOOD == evt.capture_result.quality){
				//extract features
				Engine RightFingerEngine = UareUGlobal.GetEngine();
					
				try{
					Enrolee_Right_fmd = RightFingerEngine.CreateFmd(evt.capture_result.image, Fmd.Format.ANSI_378_2004);
                                        System.out.println("Enrolee_Right Finger Extraction Sucessful>>" + Enrolee_Right_fmd.toString());
				
				}
				catch(UareUException e){
                                    DpError("Engine.CreateFmd()", e);
                                }

		}
                  else if(Reader.CaptureQuality.CANCELED == evt.capture_result.quality){
				//capture or streaming was canceled, just quit
				bCanceled = true;
			}
			else{
				//bad quality
                            BadQuality(evt.capture_result.quality);
			}
                }
		else if(null != evt.exception){
			//exception during capture
			DpError("Capture", evt.exception);
			bCanceled = true;
		}
		else if(null != evt.reader_status){
			//reader failure
			BadStatus(evt.reader_status);
			bCanceled = true;
		}
        }
//++++++++++++++++++++++++++++++++++ End of Extraction process +++++++++++++++++++++++++++++++++++++++++++++++++++++++++      
        
        
    public static String enroleeNameCaptured,enroleeIDCaptured,enroleePositionCaptured,attendeeNameCaptured,attendeeIDCaptured;
    public static CaptureThread.CaptureEvent evt;    
        private static boolean AttendanceFlag = false;
        private static boolean Enroll_Left_Flag = false;
        private static boolean Enroll_Right_Flag = false;
    public static Fiv Attendance_view;
    public static Fiv Enrolee_Left_view;
    public static Fiv Enrolee_Right_view;
    public static Fmd Attendance_fmd;
    public static Fmd Enrolee_Left_fmd;
    public static Fmd Enrolee_Right_fmd;
    	public static  ReaderCollection m_collection;
	public static  Reader m_reader;
    	private static final String ACT_SELECTION = "selection";
	private static final String ACT_CAPTURE = "capture";
	private static final String ACT_STREAMING = "streaming";
	private static final String ACT_VERIFICATION = "verification";
	private static final String ACT_IDENTIFICATION = "identification";
	private static final String ACT_ENROLLMENT = "enrollment";
	private static final String ACT_EXIT = "exit";
    private static final String ATTENDANCE_CAPTURE_COMMAND = "ATTENDANCE";
    private static final String ENROLEE_CAPTURE_COMMAND = "ENROLLMENT";
    public static ImagePanel m_image;
    public static ImagePanel left_m_image;
    public static ImagePanel right_m_image;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTabbedPane AttendanceTabPane;
    public javax.swing.JPanel EnroleeDetailsPane;
    public javax.swing.JButton EnrollButton;
    public static javax.swing.JLabel NotificationLabel;
    public javax.swing.JButton PortGateButton;
    public javax.swing.JButton ReleaseAttendanceResources;
    public javax.swing.JButton ReleaseEnrollResouces;
    public static javax.swing.JButton attendanceCatptureButton;
    public static javax.swing.JPanel attendeeButtonPane;
    public javax.swing.JPanel attendeeDetailPane;
    public static javax.swing.JTextField attendeeIDField;
    public javax.swing.JLabel attendeeIDLabel;
    public static javax.swing.JTextField attendeeNameField;
    public javax.swing.JLabel attendeeNameLabel;
    public static javax.swing.JButton enroleeCaptureButton;
    public javax.swing.JLabel enroleeID;
    public static javax.swing.JTextField enroleeIDField;
    public javax.swing.JLabel enroleeName;
    public static javax.swing.JTextField enroleeNameField;
    public javax.swing.JLabel enroleePosition;
    public static javax.swing.JTextField enroleePositionField;
    public javax.swing.JPanel enrollButtonPanel;
    public javax.swing.JPanel enrollmentPanel;
    public static javax.swing.JPanel imagePanel;
    public static javax.swing.JPanel left_imagePanel;
    public static javax.swing.JLabel notificationLabel;
    public javax.swing.JButton openReaderButton;
    public static javax.swing.JButton queryAttendanceTable;
    public static javax.swing.JButton queryEnrollmentTable;
    public static javax.swing.JPanel right_imagePanel;
    public static javax.swing.JLabel statusLabel;
    public javax.swing.JPanel verificationPanel;
    public static javax.swing.JButton verifyButton;
    // End of variables declaration//GEN-END:variables
}
