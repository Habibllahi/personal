/*
The process of 
1 capturing a fingerprint image(s) for an individual, 
2 extracting fingerprint features 
3 optionally checking for duplicates, and storing the fingerprint feature (fingerprint template).
*/
package fingerprintattendance;
import com.digitalpersona.uareu.*;
import javax.swing.JOptionPane;
public class Enrollment {
    public Enrollment() throws UareUException{
    
} 
    
}
