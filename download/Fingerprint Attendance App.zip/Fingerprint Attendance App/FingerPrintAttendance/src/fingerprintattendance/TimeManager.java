
package fingerprintattendance;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import javax.swing.JOptionPane;

public class TimeManager {
    public static  int year;
    public static Month month;
    public static int day;
    public static int hour;
    public static int minute;
    public static int seconds;
    public static String Welcome_Message;
    public static String Attendance_String;
    public static void getLocalDate_Time(){
      LocalDateTime currentTime = LocalDateTime.now();
      //System.out.println("Current DateTime: " + currentTime);
		
      LocalDate Capture_Date = currentTime.toLocalDate();
      System.out.println("You mark Attendance at " + Capture_Date);

      year = currentTime.getYear();
      month = currentTime.getMonth();
      day = currentTime.getDayOfMonth();
      hour = currentTime.getHour();
      minute = currentTime.getMinute();
      seconds = currentTime.getSecond();
      Welcome_Message =  String.format("Welcome %s \n" , AttendanceWindow.attendeeNameField.getText());
      Attendance_String = String.format("your Attendance is as Follow: \n Seconds: %02d \n Minute: %02d \n Hour: %02d \n day: %s \n Month: %s \n Year: %s \n Summary: %s" , seconds, minute,hour,day,month,year,currentTime);
      //System.out.println("Year: " + year + " Month: " + month +" day: " + day +" Hour: "+ hour +" Minute: "+ minute +" seconds: " + seconds);
      System.out.println(Welcome_Message + Attendance_String);
}
  public static void showAttendanceDetail(){
      JOptionPane.showMessageDialog(null, Welcome_Message + Attendance_String,"Attendance Detail", JOptionPane.INFORMATION_MESSAGE);
  }
}

