/*
The process of
1. Capturing a fingerprint image from an individual,
2. Extracting fingerprint features,
3. Comparing the captured image’s fingerprint
features with the fingerprint template(s) of the
enrollee this individual claims to be and
4. Making the match/non-match decision.
*/
package fingerprintattendance;

import com.digitalpersona.uareu.*;
public class Verification {
    
}
