/*
*This project is an Application that uses Finger Print module to take attendance via USB communication
*The attendee data is Registered in to MySQL data Base using the registration window
*The attendance window allows antendee to mark attendance fettching there Name, and Passport data from the data base
*Also write the punctuality status to the data base and to a Label on screen
 */
package fingerprintattendance;
import com.digitalpersona.uareu.*;
public class AppConstants {
  public static String username="gateway";
  public static String password="gateway";
  public static char[] passwordChar = {'t','o','l','u'};
  
  //this variables are declared for Fingerprint processing of this project 
    public static Fid.Format captureFormat = Fid.Format.ANSI_381_2004; //this specifies the format of the image to be recieved from the device
    public static Reader.ImageProcessing  ImageProcessingType = Reader.ImageProcessing.IMG_PROC_DEFAULT; // this specifies how the image is being processed
    public static Reader.Priority priority = Reader.Priority.COOPERATIVE;
    public static String captureForWhat = "";
    
    public AppConstants(){
    //get the reader status
        Reader.Status deviceStatus = new Reader.Status();
        boolean fingerDetected = deviceStatus.finger_detected;
        if(fingerDetected = true){
            System.out.println("Finger Detected");
        }else{
           System.out.println("No Finger Detected Yet"); 
        }
        byte[] vendor_Data = deviceStatus.vendor_data;
        String VendorData = new String(vendor_Data);
        System.out.println("Vendor Data is: "+ VendorData);
    }
}
