/*
*This project is an Application that uses Finger Print Reader to take attendance via USB communication
*The attendee data is Registered in to MySQL data Base using the Enrollment window
*The Attendance window allows antendee to mark attendance fettching there Name, and Passport data from the data base
*Also write the punctuality status to the data base and to a Label on screen
 */
package fingerprintattendance;

import com.mysql.jdbc.*;
import java.awt.Color;
import java.awt.Font;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;

/**
 *
 * @author HamzatPC
 */
public class LoginWindow extends javax.swing.JFrame {

    /**
     * Creates new form LoginWindow
     */
    public LoginWindow() {
        initComponents();
        LoginPane.setTitleAt(0, "Student Details");
        LoginPane.setTitleAt(1, "Login tab");
        LoginPane.setTabPlacement(JTabbedPane.TOP);//set the Tab Placement
        LoginPane.setTabLayoutPolicy(JTabbedPane.WRAP_TAB_LAYOUT);//policy to layout Tabs in this Tab Pane when all tab can not fit to screen at once 
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        LoginPane = new javax.swing.JTabbedPane();
        StudentDetailPane = new javax.swing.JPanel();
        SchoolLogoLabel = new javax.swing.JLabel();
        SchoolNameLabel = new javax.swing.JLabel();
        authorPane = new javax.swing.JPanel();
        NameLabel = new javax.swing.JLabel();
        Name = new javax.swing.JLabel();
        MatricLabel = new javax.swing.JLabel();
        Matric = new javax.swing.JLabel();
        SupervisorLabel = new javax.swing.JLabel();
        supervisor = new javax.swing.JLabel();
        PoweredByLabel = new javax.swing.JLabel();
        MainLoginPane = new javax.swing.JPanel();
        userNamePane = new javax.swing.JPanel();
        UserNameLabel = new javax.swing.JLabel();
        UserNameField = new javax.swing.JTextField();
        PassWordPane = new javax.swing.JPanel();
        PasswordLabel = new javax.swing.JLabel();
        passwordField = new javax.swing.JPasswordField();
        SignInPane = new javax.swing.JPanel();
        LoginButton = new javax.swing.JButton();
        LoginStatusPane = new javax.swing.JPanel();
        LoginStatusLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(520, 540));
        setMinimumSize(new java.awt.Dimension(520, 540));
        setPreferredSize(new java.awt.Dimension(520, 540));

        LoginPane.setBackground(new java.awt.Color(255, 232, 0));
        LoginPane.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        LoginPane.setMaximumSize(new java.awt.Dimension(510, 538));
        LoginPane.setMinimumSize(new java.awt.Dimension(510, 538));
        LoginPane.setPreferredSize(new java.awt.Dimension(510, 538));

        StudentDetailPane.setMaximumSize(new java.awt.Dimension(500, 500));
        StudentDetailPane.setMinimumSize(new java.awt.Dimension(500, 500));
        StudentDetailPane.setPreferredSize(new java.awt.Dimension(500, 500));
        StudentDetailPane.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        SchoolLogoLabel.setBackground(new java.awt.Color(102, 255, 102));
        SchoolLogoLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fingerprintattendance/logoo.jpeg"))); // NOI18N
        SchoolLogoLabel.setPreferredSize(new java.awt.Dimension(100, 100));
        StudentDetailPane.add(SchoolLogoLabel);

        SchoolNameLabel.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        SchoolNameLabel.setForeground(new java.awt.Color(51, 0, 204));
        SchoolNameLabel.setText("THE GATEWAY (ICT)  POLYTHECNIC SAAPADE ");
        StudentDetailPane.add(SchoolNameLabel);

        authorPane.setMaximumSize(new java.awt.Dimension(510, 300));
        authorPane.setMinimumSize(new java.awt.Dimension(510, 300));
        authorPane.setPreferredSize(new java.awt.Dimension(510, 300));
        authorPane.setLayout(new java.awt.GridLayout(3, 2, 5, 5));

        NameLabel.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        NameLabel.setText("Name:");
        authorPane.add(NameLabel);

        Name.setForeground(new java.awt.Color(0, 0, 153));
        Name.setText("Omowunmi  Tanimomo/Tolulope Awosanya");
        authorPane.add(Name);

        MatricLabel.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        MatricLabel.setText("Matric Number");
        authorPane.add(MatricLabel);

        Matric.setForeground(new java.awt.Color(0, 0, 204));
        Matric.setText("16010131005 / 16010131019");
        authorPane.add(Matric);

        SupervisorLabel.setFont(new java.awt.Font("Times New Roman", 1, 13)); // NOI18N
        SupervisorLabel.setText("Supervisor ");
        authorPane.add(SupervisorLabel);

        supervisor.setForeground(new java.awt.Color(0, 0, 204));
        supervisor.setText("Mrs. Kayode O.");
        authorPane.add(supervisor);

        StudentDetailPane.add(authorPane);

        PoweredByLabel.setText("Powered by AIfiiCode contact :08142408496 email: habibllahi3@gmail.com");
        PoweredByLabel.setMaximumSize(new java.awt.Dimension(500, 10));
        PoweredByLabel.setMinimumSize(new java.awt.Dimension(500, 10));
        PoweredByLabel.setPreferredSize(new java.awt.Dimension(500, 10));
        StudentDetailPane.add(PoweredByLabel);

        LoginPane.addTab("tab1", StudentDetailPane);

        MainLoginPane.setMaximumSize(new java.awt.Dimension(500, 500));
        MainLoginPane.setMinimumSize(new java.awt.Dimension(500, 500));
        MainLoginPane.setPreferredSize(new java.awt.Dimension(500, 500));
        MainLoginPane.setLayout(new javax.swing.BoxLayout(MainLoginPane, javax.swing.BoxLayout.Y_AXIS));

        userNamePane.setMaximumSize(new java.awt.Dimension(500, 50));
        userNamePane.setMinimumSize(new java.awt.Dimension(500, 50));
        userNamePane.setPreferredSize(new java.awt.Dimension(500, 50));

        UserNameLabel.setText("User Name");
        UserNameLabel.setMaximumSize(new java.awt.Dimension(150, 45));
        UserNameLabel.setMinimumSize(new java.awt.Dimension(150, 45));
        UserNameLabel.setPreferredSize(new java.awt.Dimension(150, 45));
        userNamePane.add(UserNameLabel);

        UserNameField.setMaximumSize(new java.awt.Dimension(300, 45));
        UserNameField.setMinimumSize(new java.awt.Dimension(300, 45));
        UserNameField.setPreferredSize(new java.awt.Dimension(300, 45));
        userNamePane.add(UserNameField);

        MainLoginPane.add(userNamePane);

        PassWordPane.setMaximumSize(new java.awt.Dimension(500, 50));
        PassWordPane.setMinimumSize(new java.awt.Dimension(500, 50));
        PassWordPane.setPreferredSize(new java.awt.Dimension(500, 50));

        PasswordLabel.setText("PassWord");
        PasswordLabel.setMaximumSize(new java.awt.Dimension(150, 45));
        PasswordLabel.setMinimumSize(new java.awt.Dimension(150, 45));
        PasswordLabel.setPreferredSize(new java.awt.Dimension(150, 45));
        PassWordPane.add(PasswordLabel);

        passwordField.setMaximumSize(new java.awt.Dimension(300, 45));
        passwordField.setMinimumSize(new java.awt.Dimension(300, 45));
        passwordField.setPreferredSize(new java.awt.Dimension(300, 45));
        PassWordPane.add(passwordField);

        MainLoginPane.add(PassWordPane);

        SignInPane.setMaximumSize(new java.awt.Dimension(500, 50));
        SignInPane.setMinimumSize(new java.awt.Dimension(500, 50));
        SignInPane.setPreferredSize(new java.awt.Dimension(500, 50));

        LoginButton.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        LoginButton.setText("Login");
        LoginButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        LoginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginButtonActionPerformed(evt);
            }
        });
        SignInPane.add(LoginButton);

        MainLoginPane.add(SignInPane);

        LoginStatusPane.setMaximumSize(new java.awt.Dimension(500, 50));
        LoginStatusPane.setMinimumSize(new java.awt.Dimension(500, 50));
        LoginStatusPane.setPreferredSize(new java.awt.Dimension(500, 50));

        LoginStatusLabel.setMaximumSize(new java.awt.Dimension(480, 50));
        LoginStatusLabel.setMinimumSize(new java.awt.Dimension(480, 50));
        LoginStatusLabel.setPreferredSize(new java.awt.Dimension(480, 50));
        LoginStatusPane.add(LoginStatusLabel);

        MainLoginPane.add(LoginStatusPane);

        LoginPane.addTab("tab2", MainLoginPane);

        getContentPane().add(LoginPane, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents
//login Button event mathod containing login button event handler codes to be use in the login button event handling 
    private void LoginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginButtonActionPerformed
       
        if(UserNameField.getText().equals(AppConstants.username) && new String(passwordField.getPassword()).equals(AppConstants.password)) {
           LoginStatusLabel.setForeground(Color.blue);
           LoginStatusLabel.setFont(new Font("Times New Roman", 1, 18));
           LoginStatusLabel.setText("Login Sucessful");
          try{
               AttendanceWindow attendanceWindow = new AttendanceWindow();
          } catch(NullPointerException e){
              e.printStackTrace();
              JOptionPane.showMessageDialog(null, e.getMessage(), "Error Opening Window", JOptionPane.ERROR_MESSAGE);
          }
           this.dispose();

       }else{
           LoginStatusLabel.setText("Invalid Login");
           LoginStatusLabel.setForeground(Color.red);
           LoginStatusLabel.setFont(new Font("Times New Roman", 1, 18));
       }
    }//GEN-LAST:event_LoginButtonActionPerformed



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton LoginButton;
    private javax.swing.JTabbedPane LoginPane;
    private javax.swing.JLabel LoginStatusLabel;
    private javax.swing.JPanel LoginStatusPane;
    private javax.swing.JPanel MainLoginPane;
    private javax.swing.JLabel Matric;
    private javax.swing.JLabel MatricLabel;
    private javax.swing.JLabel Name;
    private javax.swing.JLabel NameLabel;
    private javax.swing.JPanel PassWordPane;
    private javax.swing.JLabel PasswordLabel;
    private javax.swing.JLabel PoweredByLabel;
    private javax.swing.JLabel SchoolLogoLabel;
    private javax.swing.JLabel SchoolNameLabel;
    private javax.swing.JPanel SignInPane;
    private javax.swing.JPanel StudentDetailPane;
    private javax.swing.JLabel SupervisorLabel;
    private javax.swing.JTextField UserNameField;
    private javax.swing.JLabel UserNameLabel;
    private javax.swing.JPanel authorPane;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField passwordField;
    private javax.swing.JLabel supervisor;
    private javax.swing.JPanel userNamePane;
    // End of variables declaration//GEN-END:variables
}
