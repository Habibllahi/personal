
package fingerprintattendance;

import com.mysql.jdbc.*; //importing the mySQL connector 8.0
import java.io.ByteArrayInputStream;
import java.sql.*; //importing the JDBC
import javax.swing.JOptionPane;

public class VerificationManager extends DataBaseManager {
    private String ids;
    private ResultSet result;
    private PreparedStatement  VerificationManagerStatement;
    public static ByteArrayInputStream fetched_FMD_asInputStream;
    private String query = "SELECT FMD FROM verification WHERE ID = ?";
    public VerificationManager() throws SQLException {
        get_Parameter();
        try{ 
         VerificationManagerStatement = connector.prepareStatement(query);
         VerificationManagerStatement.setString(1, ids);
          System.out.println(">>>>>>>>>> Verification Manager Statement created  ");
        }catch(SQLException e){
                JOptionPane.showMessageDialog(null, e.getMessage(), "error creating verification Manager Statement", JOptionPane.ERROR_MESSAGE);
            }
        try{
            result = VerificationManagerStatement.executeQuery();
            System.out.println(">>>>>>>>>> Verification Manager query executed  ");
        }catch(SQLException e){
                JOptionPane.showMessageDialog(null, e.getMessage(), "error exxecuting verification Manager Query", JOptionPane.ERROR_MESSAGE);
            }
        
        while(result.next()){
            try{
            result.getBlob("FMD").getBinaryStream(1, result.getBlob("FMD").length());
            System.out.println("FMD Blob format fettching sucessful");
            }catch(SQLException e){
                JOptionPane.showMessageDialog(null, e.getMessage(), "error fetching FMD", JOptionPane.ERROR_MESSAGE);
            }
          
        }
       VerificationManagerStatement.close();
       connector.close();
    }
        public void get_Parameter(){
            ids = AttendanceWindow.attendeeIDField.getText();
            System.out.println(">>>>>>>>>> verification ID is "+ ids);     
   }
}
