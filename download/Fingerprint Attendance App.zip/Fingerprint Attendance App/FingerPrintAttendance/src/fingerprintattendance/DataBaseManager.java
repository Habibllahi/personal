
package fingerprintattendance;
import com.mysql.jdbc.*; //importing the mySQL connector 8.0
import java.sql.*; //importing the JDBC 
import javax.swing.JOptionPane;
public class DataBaseManager {
public static Connection connector = null;
private String url = "jdbc:mysql://localhost:3306/fingerprintattendance?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
private String userName = "gateway";
private String password = "gatewaysapadegateway";
   //private String generatedPassword = "2SBuTG2yAeA4gYyO";
    
    public DataBaseManager() throws SQLException{
        
        //try to load and register the mySQL connector driver
       try{
           Class.forName("com.mysql.cj.jdbc.Driver");
            } catch(ClassNotFoundException e){
           JOptionPane.showMessageDialog(null, e.getCause(), "DataBase Driver Class Not Found", JOptionPane.ERROR_MESSAGE);
       }
        //make an attempt to establish connection with the data base using the specified url, userName and password
     try{
        connector = DriverManager.getConnection(url, userName,password);
        System.out.println("connected to data base");
            } catch(SQLException e){
       JOptionPane.showMessageDialog(null, e.getMessage(), "Error Connecting to DataBase ", JOptionPane.ERROR_MESSAGE);
    }
}
}
