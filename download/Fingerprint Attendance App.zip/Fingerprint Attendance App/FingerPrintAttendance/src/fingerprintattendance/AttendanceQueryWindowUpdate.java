
package fingerprintattendance;

import java.awt.BorderLayout;
import com.mysql.jdbc.*; //importing the mySQL connector 8.0
import static fingerprintattendance.DataBaseManager.connector;
import java.awt.Dimension;
import java.sql.*; //importing the JDBC 
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.ButtonGroup;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;

public class AttendanceQueryWindowUpdate extends javax.swing.JFrame{

    
private ResultSet result;
private boolean idflag,nameflag,yearflag,monthflag,dayflag;
private int year,day,hour,minute,seconds;
private int yearmodal,daymodal,hourmodal,minutemodal,secondsmodal;
private String id,name,month;
private String idmodal,namemodal,monthmodal;
private  String query;
private static Connection connector = null;
private String url = "jdbc:mysql://localhost:3306/fingerprintattendance?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
private String userName = "gateway";
private String password = "gatewaysapadegateway";
private PreparedStatement AttendanceStatement = null;
private String tolu;
private ButtonGroup group;
//Object[] datas = { idmodal, namemodal, yearmodal, monthmodal, daymodal};




    public AttendanceQueryWindowUpdate(){
        
        initComponents();
        group = new ButtonGroup();
        group.add(IDQueryButton);
        group.add(NameQueryButton);
        group.add(YearQueryButton);
        group.add(MonthQueryButton);
        group.add(DayQueryButton); 
        QueryButton.setToolTipText("Click to Query");
        CloseButton.setToolTipText("Close Window");
        IDQueryButton.setToolTipText("Search by ID");
        NameQueryButton.setToolTipText("Search by Name");
        YearQueryButton.setToolTipText("Search by Year");
        MonthQueryButton.setToolTipText("Search by Month");
        DayQueryButton.setToolTipText("Searcg by Day");
// CREATE AN EMPTY TABLE TO DISPLAY THE QUERY RESULT.....      
        viewTable = new JTable();
        viewTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        viewTable.setMaximumSize(new Dimension(600,350));
        viewTable.setMinimumSize(new Dimension(600,350));
        viewTable.setPreferredSize(new Dimension(600,350));
        viewPane.setViewportView(viewTable);
        resultSetPanel.add(viewPane,BorderLayout.PAGE_START);
        viewTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        viewTable.setRowHeight(50);
        viewTable.setShowGrid(true);
        viewTable.setEnabled(false);//dont make it respond to user input, that is, set it to be uneditable
        setVisible(true);
//TRY CONNECTING TO DATA BASE 
        
        //try to load and register the mySQL connector driver
       try{
           Class.forName("com.mysql.cj.jdbc.Driver");
            } catch(ClassNotFoundException e){
           JOptionPane.showMessageDialog(null, e.getCause(), "DataBase Driver Class Not Found", JOptionPane.ERROR_MESSAGE);
       }
        //make an attempt to establish connection with the data base using the specified url, userName and password
     try{
        connector = DriverManager.getConnection(url, userName,password);
        System.out.println("connected to data base for Attendance table quering");
            } catch(SQLException e){
       JOptionPane.showMessageDialog(null, e.getMessage(), "Error Connecting to DataBase ", JOptionPane.ERROR_MESSAGE);
    }


//try fetching me results by executing query

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        QueryModalPanel = new javax.swing.JPanel();
        IDQueryButton = new javax.swing.JRadioButton();
        NameQueryButton = new javax.swing.JRadioButton();
        YearQueryButton = new javax.swing.JRadioButton();
        MonthQueryButton = new javax.swing.JRadioButton();
        DayQueryButton = new javax.swing.JRadioButton();
        QueryPanel = new javax.swing.JPanel();
        QueryField = new javax.swing.JTextField();
        QueryButton = new javax.swing.JButton();
        ControlPanel = new javax.swing.JPanel();
        CloseButton = new javax.swing.JButton();
        resultSetPanel = new javax.swing.JPanel();
        viewPane = new javax.swing.JScrollPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new javax.swing.BoxLayout(getContentPane(), javax.swing.BoxLayout.Y_AXIS));

        QueryModalPanel.setMaximumSize(new java.awt.Dimension(600, 50));
        QueryModalPanel.setMinimumSize(new java.awt.Dimension(600, 50));
        QueryModalPanel.setPreferredSize(new java.awt.Dimension(600, 50));

        IDQueryButton.setText("ID");
        IDQueryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IDQueryButtonActionPerformed(evt);
            }
        });
        QueryModalPanel.add(IDQueryButton);

        NameQueryButton.setText("NAME");
        NameQueryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NameQueryButtonActionPerformed(evt);
            }
        });
        QueryModalPanel.add(NameQueryButton);

        YearQueryButton.setText("YEAR");
        YearQueryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                YearQueryButtonActionPerformed(evt);
            }
        });
        QueryModalPanel.add(YearQueryButton);

        MonthQueryButton.setText("MONTH");
        MonthQueryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MonthQueryButtonActionPerformed(evt);
            }
        });
        QueryModalPanel.add(MonthQueryButton);

        DayQueryButton.setText("DAY");
        DayQueryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DayQueryButtonActionPerformed(evt);
            }
        });
        QueryModalPanel.add(DayQueryButton);

        getContentPane().add(QueryModalPanel);

        QueryPanel.setMaximumSize(new java.awt.Dimension(600, 50));
        QueryPanel.setMinimumSize(new java.awt.Dimension(600, 50));
        QueryPanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        QueryField.setMaximumSize(new java.awt.Dimension(500, 30));
        QueryField.setMinimumSize(new java.awt.Dimension(500, 30));
        QueryField.setPreferredSize(new java.awt.Dimension(500, 30));
        QueryPanel.add(QueryField);

        QueryButton.setText("Query");
        QueryButton.setMaximumSize(new java.awt.Dimension(67, 30));
        QueryButton.setMinimumSize(new java.awt.Dimension(67, 30));
        QueryButton.setPreferredSize(new java.awt.Dimension(67, 30));
        QueryButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                QueryButtonActionPerformed(evt);
            }
        });
        QueryPanel.add(QueryButton);

        getContentPane().add(QueryPanel);

        ControlPanel.setMaximumSize(new java.awt.Dimension(600, 50));
        ControlPanel.setMinimumSize(new java.awt.Dimension(600, 50));
        ControlPanel.setPreferredSize(new java.awt.Dimension(600, 50));

        CloseButton.setText("CLOSE");
        CloseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CloseButtonActionPerformed(evt);
            }
        });
        ControlPanel.add(CloseButton);

        getContentPane().add(ControlPanel);

        resultSetPanel.setMaximumSize(new java.awt.Dimension(600, 350));
        resultSetPanel.setMinimumSize(new java.awt.Dimension(600, 350));
        resultSetPanel.setLayout(new java.awt.BorderLayout());

        viewPane.setMaximumSize(new java.awt.Dimension(600, 350));
        viewPane.setMinimumSize(new java.awt.Dimension(600, 350));
        viewPane.setPreferredSize(new java.awt.Dimension(600, 350));
        resultSetPanel.add(viewPane, java.awt.BorderLayout.PAGE_START);

        getContentPane().add(resultSetPanel);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void IDQueryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IDQueryButtonActionPerformed
        if(evt.getActionCommand().equals("ID")&& evt.getSource()==IDQueryButton){
        idflag=true;
        nameflag=false;
        yearflag=false;
        monthflag=false;
        dayflag=false;
        
        }
    }//GEN-LAST:event_IDQueryButtonActionPerformed

    private void NameQueryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NameQueryButtonActionPerformed
        if(evt.getActionCommand().equals("NAME")&&evt.getSource()==NameQueryButton){      
        idflag=false;
        nameflag=true;
        yearflag=false;
        monthflag=false;
        dayflag=false;
        
        }
    }//GEN-LAST:event_NameQueryButtonActionPerformed

    private void MonthQueryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MonthQueryButtonActionPerformed
       if(evt.getActionCommand().equals("MONTH") && evt.getSource()==MonthQueryButton){    
        idflag=false;
        nameflag=false;
        yearflag=false;
        monthflag=true;
        dayflag=false;
        
       }
    }//GEN-LAST:event_MonthQueryButtonActionPerformed

    private void YearQueryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_YearQueryButtonActionPerformed
      if(evt.getActionCommand().equals("YEAR") && evt.getSource()==YearQueryButton){     
        idflag=false;
        nameflag=false;
        yearflag=true;
        monthflag=false;
        dayflag=false;
        
      }
    }//GEN-LAST:event_YearQueryButtonActionPerformed

    private void DayQueryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DayQueryButtonActionPerformed
        if(evt.getActionCommand().equals("DAY")&& evt.getSource()==DayQueryButton){       
        idflag=false;
        nameflag=false;
        yearflag=false;
        monthflag=false;
        dayflag=true;
        
        }
    }//GEN-LAST:event_DayQueryButtonActionPerformed

    private void CloseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CloseButtonActionPerformed
       if(evt.getActionCommand().equals("CLOSE")){
           this.dispose();
       }
    }//GEN-LAST:event_CloseButtonActionPerformed

@SuppressWarnings("empty-statement")
    private void QueryButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_QueryButtonActionPerformed
if(evt.getActionCommand().equals("Query")&& evt.getSource()==QueryButton){
//create a statement for quering 
     try{
         if(idflag==true){
            id = QueryField.getText();
            query = "SELECT ID,NAME,YEAR,MONTH,DAY FROM attendance WHERE ID=?";
            AttendanceStatement = connector.prepareStatement(query);
            AttendanceStatement.setString(1, id);
         }else if(nameflag==true){
            name = QueryField.getText();
            query = "SELECT ID,NAME,YEAR,MONTH,DAY FROM attendance WHERE NAME=? ";             
           AttendanceStatement = connector.prepareStatement(query);
           AttendanceStatement.setString(1, name);  
         }else if(yearflag==true){
              year = Integer.parseInt(QueryField.getText());
              query = "SELECT ID,NAME,YEAR,MONTH,DAY FROM attendance WHERE YEAR=? ";
             AttendanceStatement = connector.prepareStatement(query);
             AttendanceStatement.setInt(1, year);
         }else if(monthflag==true){
                month = QueryField.getText();
                query = "SELECT ID,NAME,YEAR,MONTH,DAY FROM attendance WHERE MONTH=? ";
             AttendanceStatement = connector.prepareStatement(query);
             AttendanceStatement.setString(1, month);
         }else if(dayflag==true){
             day = Integer.parseInt(QueryField.getText());
             query = "SELECT ID,NAME,YEAR,MONTH,DAY FROM attendance WHERE DAY=? "; 
             AttendanceStatement = connector.prepareStatement(query);
             AttendanceStatement.setInt(1, day);
         }
     }catch(SQLException e){
         JOptionPane.showMessageDialog(null, e.getCause(), "Could not create attendance quering statement ", JOptionPane.ERROR_MESSAGE);
     }
//try to execute the query
        try{
          result = AttendanceStatement.executeQuery();
//try to process result to a JTable
          // FIRST: get the number of columen in the table
          
          ColNumber = result.getMetaData().getColumnCount();
          //SECOND: get the number of row in the table
          result.last();
          RowNumber = result.getRow();
          System.out.println("You have  " + RowNumber + " rows\n"); //Just print to the console the number of roles in the table for debuging purpose          
          
          //THIRD: decleare the array to hold datas of each coulmn cell in a row          
          Object[] datas = new Object[ColNumber];
          
          //FORTH: initialize an array to create the column names
          String[] ColumeNames = {"ID","NAME","YEAR","MONTH","DAY"};//An Array to display the column Name in the table
          //FIFTH: Decleare an array to generate the table body
          Object[][] rowData = new Object[RowNumber][5];
          //SIXTH: Ensure the result set cursor is at 0   
          result.beforeFirst();
          
          //SEVENTH: create a while loop to assign value to the array decleared at the FIFTH step
          while(result.next()){ 
                //obtain database data of each column from the row the resultSet pointer is currently at.                  
                idmodal = result.getString("ID");
                namemodal = result.getString("NAME");
                yearmodal = result.getInt("YEAR");
                monthmodal = result.getString("MONTH");
                daymodal = result.getInt("DAY");
                //assign each of the datas to the various index of data array created at the THIRD step
                datas[0] = idmodal;
                datas[1] = namemodal;
                datas[2] = yearmodal;
                datas[3] = monthmodal;
                datas[4] = daymodal;
                //print out the datas at this current row for debugging purpose
        tolu = String.format("%s\t %s\t %s\t  %s\t %s\t @ %02d\n",idmodal,namemodal,yearmodal,monthmodal,daymodal,result.getRow());
        System.out.println( tolu);//WRITE TO CONSOLE SCREEN
                //create a for loop that assign data to the JTable colums for this current row
                    for( col=0; col < 5; col++){
                       System.out.println("Creating row " + result.getRow() + " col " +col+ " datas");
                       rowData[result.getRow()-1][col] = datas[col];

                    }
                 

          }//Quit this while loop once there is no more roll in the resultSet
          
          //EIGHT: Create a JTable Model from the rowData and ColumeNames array creates decleared above, by this stage all indixes in thes two array have gotten an assigned value
            DefaultTableModel model = new DefaultTableModel(rowData , ColumeNames); //DefaultTableModel extends AbstractTableModel which implements TableModel
          //NINTH: set viewTable Model as the created Model
            viewTable.setModel(model);
      }catch(SQLException|NullPointerException|ArrayIndexOutOfBoundsException  e){
         JOptionPane.showMessageDialog(null, e.getMessage(), "Could not execute query on attendance table ", JOptionPane.ERROR_MESSAGE);
     }
}   
    }//GEN-LAST:event_QueryButtonActionPerformed

 public static void runTable(){
     new AttendanceQueryWindowUpdate();
     
 }   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CloseButton;
    private javax.swing.JPanel ControlPanel;
    private javax.swing.JRadioButton DayQueryButton;
    private javax.swing.JRadioButton IDQueryButton;
    private javax.swing.JRadioButton MonthQueryButton;
    private javax.swing.JRadioButton NameQueryButton;
    private javax.swing.JButton QueryButton;
    private javax.swing.JTextField QueryField;
    private javax.swing.JPanel QueryModalPanel;
    private javax.swing.JPanel QueryPanel;
    private javax.swing.JRadioButton YearQueryButton;
    private javax.swing.JPanel resultSetPanel;
    private javax.swing.JScrollPane viewPane;
    // End of variables declaration//GEN-END:variables
    private static int ColNumber,col; //number of columns in the resultSet
    private static int RowNumber,row; //number of rows in the result set
    private JTable viewTable;
}
